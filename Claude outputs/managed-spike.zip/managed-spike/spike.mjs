// Prueba de viabilidad: ¿la skill gbit-doc-iso9001 (con su script de Python) funciona en Claude Managed Agents?
// Uso (PowerShell, en esta carpeta):
//   $env:ANTHROPIC_API_KEY = "sk-ant-..."        (tu clave; no la compartas)
//   npm install
//   node spike.mjs "C:\ruta\a\gbit-doc-iso9001"   (carpeta de la skill, la que contiene SKILL.md)
// Opciones por variable de entorno: MODEL (por defecto claude-sonnet-4-5), PROMPT (texto del pedido).
// Para borrar lo creado en tu cuenta: node spike.mjs --cleanup
import Anthropic, { toFile } from "@anthropic-ai/sdk";
import fs from "node:fs";
import path from "node:path";

const BETA = "managed-agents-2026-04-01";
const IDS = "ids.json";
const MODEL = process.env.MODEL || "claude-sonnet-4-5";
const PROMPT =
  process.env.PROMPT ||
  "Genera un documento Word de prueba con la skill gbit-doc-iso9001. Empresa: Global Business IT Corp. Tipo: INF. Área: QAS. Proyecto: INT. Elaborado por: Alexa Margarita. Contenido: una sección 'Objetivo' con dos frases de ejemplo. Guarda el .docx en /mnt/session/outputs/.";

if (!process.env.ANTHROPIC_API_KEY) {
  console.error("Falta ANTHROPIC_API_KEY. En PowerShell: $env:ANTHROPIC_API_KEY = \"sk-ant-...\"");
  process.exit(1);
}
const client = new Anthropic();
const ids = fs.existsSync(IDS) ? JSON.parse(fs.readFileSync(IDS, "utf8")) : {};
const save = () => fs.writeFileSync(IDS, JSON.stringify(ids, null, 2));
const step = (m) => console.log(`\n== ${m}`);

if (process.argv[2] === "--cleanup") {
  for (const [label, fn] of [
    ["agente", () => ids.agent && client.beta.agents.archive?.(ids.agent)],
    ["entorno", () => ids.env && client.beta.environments.delete?.(ids.env)],
    ["skill", () => ids.skill && client.beta.skills.delete?.(ids.skill)],
  ]) {
    try { await fn(); console.log("borrado:", label); } catch (e) { console.log(`no se pudo borrar ${label}: ${e.message}`); }
  }
  fs.rmSync(IDS, { force: true });
  process.exit(0);
}

const skillDir = process.argv[2];
function walk(dir, base = dir, acc = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isSymbolicLink()) continue;
    if (e.isDirectory()) walk(p, base, acc);
    else acc.push(p);
  }
  return acc;
}

try {
  // 1) Skill
  if (!ids.skill) {
    if (!skillDir || !fs.existsSync(path.join(skillDir, "SKILL.md"))) {
      console.error("Indica la carpeta de la skill (la que contiene SKILL.md): node spike.mjs \"C:\\ruta\\gbit-doc-iso9001\"");
      process.exit(1);
    }
    step("Subiendo la skill");
    const top = path.basename(path.resolve(skillDir));
    const files = [];
    for (const f of walk(skillDir)) {
      const rel = path.relative(skillDir, f).split(path.sep).join("/");
      files.push(await toFile(fs.readFileSync(f), `${top}/${rel}`));
    }
    const sk = await client.beta.skills.create({ files });
    ids.skill = sk.id;
    save();
    console.log("skill:", sk.id, `(${files.length} archivos)`);
  }

  // 2) Entorno: Python con paquetes y red solo hacia Supabase + gestores de paquetes
  if (!ids.env) {
    step("Creando el entorno");
    const env = await client.beta.environments.create({
      name: "spike-gbit",
      config: {
        type: "cloud",
        packages: { pip: ["python-docx", "openpyxl", "pillow", "requests", "lxml"] },
        networking: { type: "limited", allowed_hosts: ["kaffqbjzgkoxzkrocovp.supabase.co"], allow_package_managers: true },
      },
    });
    ids.env = env.id;
    save();
    console.log("entorno:", env.id);
  }

  // 3) Agente
  if (!ids.agent) {
    step("Creando el agente");
    const agent = await client.beta.agents.create({
      name: "spike-gbit",
      model: MODEL,
      system:
        "Eres un asistente de documentos de la empresa. Usa la skill que corresponda y respeta sus instrucciones. Guarda siempre los archivos generados en /mnt/session/outputs/. Responde en español.",
      tools: [
        {
          type: "agent_toolset_20260401",
          configs: [
            { name: "web_search", enabled: false },
            { name: "web_fetch", enabled: false },
          ],
        },
      ],
      skills: [{ type: "custom", skill_id: ids.skill }],
    });
    ids.agent = agent.id;
    save();
    console.log("agente:", agent.id);
  }

  // 4) Sesión + mensaje
  step("Ejecutando (puede tardar 1-3 minutos)");
  const session = await client.beta.sessions.create({ agent: ids.agent, environment_id: ids.env, title: "Prueba gbit-doc-iso9001" });
  console.log("sesión:", session.id);
  const t0 = Date.now();
  const stream = await client.beta.sessions.events.stream(session.id);
  await client.beta.sessions.events.send(session.id, { events: [{ type: "user.message", content: [{ type: "text", text: PROMPT }] }] });

  const deadline = setTimeout(() => { console.error("\nTiempo agotado (8 min)."); process.exit(2); }, 8 * 60_000);
  loop: for await (const ev of stream) {
    switch (ev.type) {
      case "agent.message":
        for (const b of ev.content) if (b.type === "text") process.stdout.write(b.text);
        break;
      case "agent.tool_use":
        console.log(`\n[herramienta: ${ev.name}]`);
        break;
      case "session.error":
        console.error("\n[ERROR]", ev.error?.message ?? JSON.stringify(ev.error));
        break;
      case "session.status_idle": {
        const r = ev.stop_reason?.type;
        if (r === "requires_action") {
          for (const id of ev.stop_reason.event_ids ?? [])
            await client.beta.sessions.events.send(session.id, { events: [{ type: "user.tool_confirmation", tool_use_id: id, result: "allow" }] });
          break;
        }
        console.log(`\n[fin: ${r}] ${((Date.now() - t0) / 1000).toFixed(0)} s`);
        break loop;
      }
    }
  }
  clearTimeout(deadline);

  // 5) Archivos generados
  step("Archivos generados");
  await new Promise((r) => setTimeout(r, 4000)); // pueden tardar unos segundos en aparecer
  let list = await client.beta.files.list({ scope_id: session.id, betas: [BETA] });
  let items = list.data ?? [];
  if (!items.length) {
    await new Promise((r) => setTimeout(r, 6000));
    items = (await client.beta.files.list({ scope_id: session.id, betas: [BETA] })).data ?? [];
  }
  fs.mkdirSync("salida", { recursive: true });
  for (const f of items) {
    const res = await client.beta.files.download(f.id, { betas: [BETA] });
    const dest = path.join("salida", path.basename(f.filename));
    fs.writeFileSync(dest, Buffer.from(await res.arrayBuffer()));
    console.log("guardado:", dest);
  }
  if (!items.length) console.log("No se generó ningún archivo. Copia aquí el texto de arriba para revisarlo.");
  console.log(`\nResultado: ${items.some((f) => /\.docx$/i.test(f.filename)) ? "OK, se generó el Word" : "SIN Word"}`);
} catch (e) {
  console.error("\nError:", e.status ?? "", e.message);
  if (e.error) console.error(JSON.stringify(e.error).slice(0, 600));
  process.exit(1);
}
