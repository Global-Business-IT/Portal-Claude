# Prueba: skill ISO en Claude Managed Agents

1. Instala Node (ya lo tienes) y abre PowerShell en esta carpeta.
2. `npm install`
3. `$env:ANTHROPIC_API_KEY = "sk-ant-..."`  (tu clave; no la pegues en el chat)
4. `node spike.mjs "C:\ruta\a\gbit-doc-iso9001"`  (carpeta de la skill, con SKILL.md dentro)
   - Si ya sincronizaste skills en el portal, suele estar en `portal-claude\server\data\skills-repo\.claude\skills\gbit-doc-iso9001`.
5. Revisa la carpeta `salida` (el .docx) y pégame el texto que imprime.
6. Al terminar: `node spike.mjs --cleanup` borra lo creado en tu cuenta.
